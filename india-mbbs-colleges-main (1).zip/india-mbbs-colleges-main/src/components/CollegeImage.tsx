import { useState, useEffect } from "react";
import placeholder1 from "@/assets/college-placeholder-1.jpg";
import placeholder2 from "@/assets/college-placeholder-2.jpg";
import placeholder3 from "@/assets/college-placeholder-3.jpg";
import placeholder4 from "@/assets/college-placeholder-4.jpg";
import placeholder5 from "@/assets/college-placeholder-5.jpg";
import placeholder6 from "@/assets/college-placeholder-6.jpg";

const placeholders = [placeholder1, placeholder2, placeholder3, placeholder4, placeholder5, placeholder6];

interface CollegeImageProps {
  collegeName: string;
  collegeId: number;
  className?: string;
  iconSize?: string;
}

const CollegeImage = ({ collegeName, collegeId, className = "h-32" }: CollegeImageProps) => {
  const [imageUrl, setImageUrl] = useState<string | null>(null);
  const [tried, setTried] = useState(false);

  useEffect(() => {
    let cancelled = false;

    const fetchWikipediaImage = async () => {
      try {
        const searchTitle = collegeName.replace(/\s*\(.*?\)\s*/g, " ").trim();
        const response = await fetch(
          `https://en.wikipedia.org/w/api.php?action=query&titles=${encodeURIComponent(searchTitle)}&prop=pageimages&format=json&pithumbsize=400&origin=*`
        );
        const data = await response.json();
        const pages = data.query?.pages;
        if (pages) {
          const page = Object.values(pages)[0] as any;
          if (page?.thumbnail?.source && !cancelled) {
            setImageUrl(page.thumbnail.source);
          }
        }
      } catch {
        // Will use placeholder
      } finally {
        if (!cancelled) setTried(true);
      }
    };

    fetchWikipediaImage();
    return () => { cancelled = true; };
  }, [collegeName]);

  const src = imageUrl || placeholders[collegeId % placeholders.length];

  const isPlaceholder = !imageUrl;

  return (
    <div className={`${className} rounded-t-lg overflow-hidden relative`}>
      <img
        src={src}
        alt={collegeName}
        className="w-full h-full object-cover"
        loading="lazy"
        onError={() => {
          if (imageUrl) setImageUrl(null);
        }}
      />
      {isPlaceholder && tried && (
        <span className="absolute bottom-1.5 left-1.5 bg-black/60 text-white text-[10px] px-1.5 py-0.5 rounded">
          AI Generated
        </span>
      )}
    </div>
  );
};

export default CollegeImage;
