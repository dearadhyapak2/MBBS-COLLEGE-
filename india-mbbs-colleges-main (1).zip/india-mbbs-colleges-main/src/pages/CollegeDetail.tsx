import { useParams, Link } from "react-router-dom";
import { colleges } from "@/data/colleges";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { GraduationCap, MapPin, Calendar, Users, Building2, ArrowLeft } from "lucide-react";
import CollegeImage from "@/components/CollegeImage";

const CollegeDetail = () => {
  const { id } = useParams();
  const college = colleges.find((c) => c.id === Number(id));

  if (!college) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <h1 className="text-2xl font-bold mb-4">कॉलेज नहीं मिला</h1>
          <Link to="/">
            <Button><ArrowLeft className="h-4 w-4 mr-2" />वापस जाएं</Button>
          </Link>
        </div>
      </div>
    );
  }

  const stateColleges = colleges.filter(
    (c) => c.state === college.state && c.id !== college.id
  ).slice(0, 4);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground">
        <div className="max-w-4xl mx-auto px-4 py-8">
          <Link to="/" className="inline-flex items-center gap-1 text-primary-foreground/80 hover:text-primary-foreground mb-4 text-sm">
            <ArrowLeft className="h-4 w-4" />
            सभी कॉलेज
          </Link>
          <div className="flex items-start gap-4">
            <div className="rounded-xl overflow-hidden shrink-0">
              <CollegeImage
                collegeName={college.name}
                collegeId={college.id}
                className="h-20 w-20"
                iconSize="h-10 w-10"
              />
            </div>
            <div>
              <h1 className="text-2xl sm:text-3xl font-bold mb-2">{college.name}</h1>
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant={college.type === "Government" ? "default" : "secondary"} className="text-xs">
                  {college.type === "Government" ? "सरकारी" : "प्राइवेट"}
                </Badge>
                <span className="flex items-center gap-1 text-sm opacity-90">
                  <MapPin className="h-3.5 w-3.5" />
                  {college.city}, {college.state}
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Details */}
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8">
          <Card>
            <CardContent className="p-5 flex items-center gap-3">
              <Calendar className="h-8 w-8 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">स्थापना वर्ष</p>
                <p className="text-xl font-bold">{college.established}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5 flex items-center gap-3">
              <Users className="h-8 w-8 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">MBBS सीटें</p>
                <p className="text-xl font-bold">{college.seats}</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5 flex items-center gap-3">
              <Building2 className="h-8 w-8 text-primary" />
              <div>
                <p className="text-sm text-muted-foreground">प्रकार</p>
                <p className="text-xl font-bold">{college.type === "Government" ? "सरकारी" : "प्राइवेट"}</p>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card className="mb-8">
          <CardContent className="p-6">
            <h2 className="text-lg font-semibold mb-3">कॉलेज के बारे में</h2>
            <p className="text-muted-foreground leading-relaxed">
              {college.name} {college.city}, {college.state} में स्थित एक प्रतिष्ठित {college.type === "Government" ? "सरकारी" : "निजी"} मेडिकल कॉलेज है। 
              यह कॉलेज {college.established} में स्थापित किया गया था और वर्तमान में इसमें {college.seats} MBBS सीटें उपलब्ध हैं।
              यह कॉलेज राष्ट्रीय चिकित्सा आयोग (NMC) द्वारा मान्यता प्राप्त है।
            </p>
          </CardContent>
        </Card>

        {/* Same State Colleges */}
        {stateColleges.length > 0 && (
          <div>
            <h2 className="text-lg font-semibold mb-4">{college.state} के अन्य कॉलेज</h2>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {stateColleges.map((c) => (
                <Link key={c.id} to={`/college/${c.id}`}>
                  <Card className="hover:shadow-md transition-shadow cursor-pointer">
                    <CardContent className="p-4 flex items-center gap-3">
                      <GraduationCap className="h-8 w-8 text-muted-foreground shrink-0" />
                      <div className="min-w-0">
                        <p className="font-medium text-sm truncate">{c.name}</p>
                        <p className="text-xs text-muted-foreground">{c.city} • {c.seats} सीटें</p>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default CollegeDetail;
