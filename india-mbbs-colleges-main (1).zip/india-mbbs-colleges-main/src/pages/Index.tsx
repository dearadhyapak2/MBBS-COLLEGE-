import { useState, useMemo } from "react";
import { colleges, states } from "@/data/colleges";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Search, GraduationCap, MapPin, Building2, Users, ChevronLeft, ChevronRight, Calendar } from "lucide-react";
import { Link } from "react-router-dom";
import CollegeImage from "@/components/CollegeImage";

const ITEMS_PER_PAGE = 24;

const Index = () => {
  const [search, setSearch] = useState("");
  const [selectedState, setSelectedState] = useState("all");
  const [page, setPage] = useState(1);

  const filtered = useMemo(() => {
    return colleges.filter((c) => {
      const matchesSearch =
        !search ||
        c.name.toLowerCase().includes(search.toLowerCase()) ||
        c.city.toLowerCase().includes(search.toLowerCase()) ||
        c.state.toLowerCase().includes(search.toLowerCase());
      const matchesState = selectedState === "all" || c.state === selectedState;
      return matchesSearch && matchesState;
    });
  }, [search, selectedState]);

  const totalPages = Math.ceil(filtered.length / ITEMS_PER_PAGE);
  const paginated = filtered.slice((page - 1) * ITEMS_PER_PAGE, page * ITEMS_PER_PAGE);

  const handleSearch = (val: string) => {
    setSearch(val);
    setPage(1);
  };

  const handleStateChange = (val: string) => {
    setSelectedState(val);
    setPage(1);
  };


  return (
    <div className="min-h-screen bg-background">
      {/* Hero Header */}
      <header className="relative overflow-hidden bg-primary text-primary-foreground">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-10 left-10 w-72 h-72 rounded-full bg-primary-foreground blur-3xl" />
          <div className="absolute bottom-10 right-10 w-96 h-96 rounded-full bg-primary-foreground blur-3xl" />
        </div>
        <div className="relative max-w-7xl mx-auto px-4 py-12 sm:py-16">
          <div className="flex items-center gap-3 mb-3">
            <GraduationCap className="h-10 w-10" />
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold tracking-tight">
              भारत के MBBS कॉलेज
            </h1>
          </div>
          <p className="text-lg sm:text-xl opacity-90 max-w-2xl">
            भारत के सभी {colleges.length} MBBS कॉलेजों की पूरी सूची — नाम, जगह और जानकारी के साथ
          </p>

          {/* Search & Filter */}
          <div className="mt-8 flex flex-col sm:flex-row gap-3 max-w-2xl">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="कॉलेज का नाम या शहर खोजें..."
                value={search}
                onChange={(e) => handleSearch(e.target.value)}
                className="pl-10 bg-background text-foreground h-12 text-base"
              />
            </div>
            <Select value={selectedState} onValueChange={handleStateChange}>
              <SelectTrigger className="w-full sm:w-56 bg-background text-foreground h-12">
                <MapPin className="h-4 w-4 mr-2 text-muted-foreground" />
                <SelectValue placeholder="राज्य चुनें" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">सभी राज्य</SelectItem>
                {states.map((state) => (
                  <SelectItem key={state} value={state}>
                    {state} ({colleges.filter((c) => c.state === state).length})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </header>

      {/* Results Summary */}
      <div className="max-w-7xl mx-auto px-4 py-6">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <p className="text-muted-foreground text-sm">
            <span className="font-semibold text-foreground">{filtered.length}</span> कॉलेज मिले
            {selectedState !== "all" && (
              <span> — <Badge variant="secondary">{selectedState}</Badge></span>
            )}
            {search && (
              <span> — "{search}" के लिए</span>
            )}
          </p>
          <p className="text-muted-foreground text-sm">
            पेज {page} / {totalPages || 1}
          </p>
        </div>
      </div>

      {/* Cards Grid */}
      <main className="max-w-7xl mx-auto px-4 pb-8">
        {paginated.length === 0 ? (
          <div className="text-center py-20">
            <GraduationCap className="h-16 w-16 mx-auto text-muted-foreground/40 mb-4" />
            <h2 className="text-xl font-semibold text-muted-foreground">कोई कॉलेज नहीं मिला</h2>
            <p className="text-muted-foreground mt-1">अपनी search बदलकर देखें</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {paginated.map((college) => (
              <Link key={college.id} to={`/college/${college.id}`}>
                <Card className="group h-full hover:shadow-lg transition-all duration-200 hover:-translate-y-0.5 cursor-pointer border-border/60">
                  {/* College Image */}
                  <div className="relative">
                    <CollegeImage collegeName={college.name} collegeId={college.id} />
                    <Badge
                      className="absolute top-3 right-3 text-xs"
                      variant={college.type === "Government" ? "default" : "secondary"}
                    >
                      {college.type === "Government" ? "सरकारी" : "प्राइवेट"}
                    </Badge>
                  </div>

                  <CardContent className="p-4 space-y-2">
                    <h3 className="font-semibold text-sm leading-snug line-clamp-2 group-hover:text-primary transition-colors min-h-[2.5rem]">
                      {college.name}
                    </h3>
                    <div className="flex items-center gap-1.5 text-muted-foreground text-xs">
                      <MapPin className="h-3.5 w-3.5 shrink-0" />
                      <span className="truncate">{college.city}, {college.state}</span>
                    </div>
                    <div className="flex items-center justify-between pt-1">
                      <div className="flex items-center gap-1 text-muted-foreground text-xs">
                        <Calendar className="h-3.5 w-3.5" />
                        <span>Est. {college.established}</span>
                      </div>
                      <div className="flex items-center gap-1 text-muted-foreground text-xs">
                        <Users className="h-3.5 w-3.5" />
                        <span>{college.seats} सीटें</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-2 mt-8 flex-wrap">
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
            >
              <ChevronLeft className="h-4 w-4 mr-1" />
              पिछला
            </Button>
            {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
              let pageNum: number;
              if (totalPages <= 7) {
                pageNum = i + 1;
              } else if (page <= 4) {
                pageNum = i + 1;
              } else if (page >= totalPages - 3) {
                pageNum = totalPages - 6 + i;
              } else {
                pageNum = page - 3 + i;
              }
              return (
                <Button
                  key={pageNum}
                  variant={page === pageNum ? "default" : "outline"}
                  size="sm"
                  onClick={() => setPage(pageNum)}
                  className="min-w-[2.5rem]"
                >
                  {pageNum}
                </Button>
              );
            })}
            <Button
              variant="outline"
              size="sm"
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
            >
              अगला
              <ChevronRight className="h-4 w-4 ml-1" />
            </Button>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t bg-muted/30 py-6">
        <div className="max-w-7xl mx-auto px-4 text-center text-sm text-muted-foreground">
          <p>भारत के {colleges.length} MBBS कॉलेजों की सम्पूर्ण सूची</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
